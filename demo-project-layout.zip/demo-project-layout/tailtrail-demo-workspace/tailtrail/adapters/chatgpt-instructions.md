# TailTrail For ChatGPT

Use this file when ChatGPT is working with this repository or when these instructions are uploaded as project context.

## Operating Mode

TailTrail prefers small, grounded, reuse-first changes.

<!-- tailtrail-governance:start -->
- Read relevant source, callers, tests, configuration, and policy before changing code.
- Reuse existing helpers, types, conventions, validation style, and project patterns before adding new abstractions.
- Prefer standard library, platform-native behavior, framework capabilities, and already-installed dependencies before adding packages.
- Make the smallest maintainable change that solves the root problem without unrelated rewrites or formatting churn.
- Preserve safeguards: authentication, authorization, validation, escaping, accessibility, data integrity, privacy, logging, auditability, error handling, data-loss prevention, and explicit user requirements.
- Do not claim tests, builds, scans, pushes, deployments, merges, or approvals succeeded unless they actually ran and succeeded.
- Preserve exact source, diffs, configs, commands, file paths, IDs, hashes, dependency names and versions, security rules, policy text, and logs when exactness affects the task.
- Token saving must not hide material facts or make validation, policy, security, dependency, or source evidence lossy.
- Use `tailtrail-policy.md` when present, and never let local policy, project memory, summaries, or learnings weaken explicit safety rules.
<!-- tailtrail-governance:end -->

- Understand the request before proposing code.
- Read relevant source, callers, tests, and configuration before editing.
- Reuse existing helpers, conventions, types, components, error handling, and test style.
- Prefer standard library, platform-native features, framework capabilities, and installed dependencies.
- Use `DEPENDENCY-GATE.md` before suggesting a new package or service.
- Preserve security, validation, authorization, escaping, accessibility, data integrity, error handling, and explicit user requirements.
- Apply `GUARDRAILS.md` for non-trivial, risky, dependency-sensitive, lifecycle-driven, review-heavy, or unclear work.
- Use `context/guardrail-layers.md` for the relevant implementation, review, QA, dependency, AIDLC, handoff, CI/Sonar, release, or token-saving layer.
- Do not claim tests passed, code was pushed, a deployment happened, or approval was granted unless that action actually succeeded.
- If `tailtrail-policy.md` exists, follow it for local commands, validation expectations, dependency approvals, restricted folders, ownership, and security requirements. Treat `tailtrail-policy.example.md` as a template only.

## Context Discipline

Apply Token Autopilot automatically:

- Skip routing for tiny low-risk requests.
- Route non-trivial, broad, risky, noisy, review, dependency, AIDLC, or handoff work to one slice.
- Use `context/TailTrail.map.md` only when routing is useful.
- Keep exact text for code, diffs, configs, commands, dependency versions, paths, IDs, hashes, logs needed for diagnosis, and security rules.

Use `AIDLC.md` for larger lifecycle work. Use `aidlc/stages/handoff.md` when work needs to move to another person, model, reviewer, or operations owner.

Use only relevant sections from `GUARDRAILS.md` and only the relevant layer from `context/guardrail-layers.md`. Preserve exact code, diffs, configs, commands, dependency versions, IDs, paths, hashes, security rules, policy text, and logs being debugged.

## Short TailTrail Commands

When the user says `hello tailtrail`, `tailtrail hello`, `use TailTrail`, `use review`, `use dependency gate`, `use AIDLC`, `use AIDLC and review`, `review then AIDLC`, `use handoff`, or `save tokens`, resolve the command before answering.

For `hello tailtrail`, `hello TailTrail`, `hello taitrail`, or `tailtrail hello`, run `tailtrail hello` when the launcher is installed, otherwise run `python3 scripts/tailtrail.py hello`. Show the command output; do not replace it with a conversational greeting.

If `scripts/expand-intent.py` is available, use it as the backend intent agent. If not, use `context/intent-aliases.md` and apply the matching flow manually.

Respect prompt overrides in `.tailtrail/intent-overrides.json` or `tailtrail/intent-overrides.json` when present.

Supported short commands also include `use delivery flow`, `use risk flow`, `use release flow`, `use architecture review`, `use security review`, `use QA review`, `use CI Sonar`, `use maintainability review`, `use dependency review`, and `project learnings`.

## Output

Be concise. Say what changed, what was reused, what was intentionally skipped, what validation ran, what evidence supports non-trivial work, and what risk remains.
