# TailTrail For Claude

Use TailTrail as the project workflow for local development.

## Core Behavior

<!-- tailtrail-governance:start -->
- Read relevant source, callers, tests, configuration, and policy before changing code.
- Reuse existing helpers, types, conventions, validation style, and project patterns before adding new abstractions.
- Prefer standard library, platform-native behavior, framework capabilities, and already-installed dependencies before adding packages.
- Make the smallest maintainable change that solves the root problem without unrelated rewrites or formatting churn.
- Preserve safeguards: authentication, authorization, validation, escaping, accessibility, data integrity, privacy, logging, auditability, error handling, data-loss prevention, and explicit user requirements.
- Do not claim tests, builds, scans, pushes, deployments, merges, or approvals succeeded unless they actually ran and succeeded.
- Preserve exact source, diffs, configs, commands, file paths, IDs, hashes, dependency names and versions, security rules, policy text, and logs when exactness affects the task.
- Token saving must not hide material facts or make validation, policy, security, dependency, or source evidence lossy.
- Use `tailtrail-policy.md` when present, and never let local policy, project memory, summaries, or learnings weaken explicit safety rules.
<!-- tailtrail-governance:end -->

- Read the task fully before editing.
- Inspect the relevant source, callers, tests, and data flow.
- Reuse existing helpers, types, components, conventions, and test style.
- Prefer standard library, platform-native behavior, framework features, and already-installed dependencies.
- Avoid new dependencies unless `DEPENDENCY-GATE.md` clearly approves them.
- Make the smallest maintainable change that solves the real problem.
- Preserve validation, authorization, escaping, accessibility, data integrity, error handling, and explicit user requirements.
- Apply `GUARDRAILS.md` for non-trivial, risky, dependency-sensitive, lifecycle-driven, review-heavy, or unclear work.
- Use `context/guardrail-layers.md` for the relevant implementation, review, QA, dependency, AIDLC, handoff, CI/Sonar, release, or token-saving layer.
- Do not claim tests passed, code was pushed, a deployment happened, or approval was granted unless that action actually succeeded.
- If `tailtrail-policy.md` exists, follow it for local commands, validation expectations, dependency approvals, restricted folders, ownership, and security requirements. Treat `tailtrail-policy.example.md` as a template only.

## Context Loading

Apply Token Autopilot automatically before loading TailTrail context:

- If the request is tiny and low-risk, skip routing and do not load TailTrail docs.
- If the request is non-trivial, broad, risky, noisy, review-heavy, dependency-sensitive, or lifecycle-related, route to one slice.
- Keep code, diffs, configs, commands, file paths, IDs, hashes, dependency versions, stack traces, and security rules exact.

When routing is useful, start with `context/TailTrail.map.md` for broad or repeated work. Load one slice from `context/slices.md`, then exact source files.

Do not load `DESIGN.md`, `ROADMAP.md`, all examples, all AIDLC artifacts, or raw logs unless the task specifically needs them.

If local scripts are available, use `python3 scripts/token-auto.py "<prompt>"` or `python3 hooks/token-autopilot-hook.py "<prompt>"` for the backend decision.

## Short TailTrail Commands

When the user says `hello tailtrail`, `tailtrail hello`, `use TailTrail`, `use review`, `use dependency gate`, `use AIDLC`, `use AIDLC and review`, `review then AIDLC`, `use handoff`, or `save tokens`, expand the intent before acting.

For `hello tailtrail`, `hello TailTrail`, `hello taitrail`, or `tailtrail hello`, run `tailtrail hello` when the launcher is installed, otherwise run `python3 scripts/tailtrail.py hello`. Show the command output; do not replace it with a conversational greeting.

If local scripts are available, run `python3 scripts/expand-intent.py "<user phrase>"` and follow the expanded prompt, load list, avoid list, and run order. If the script is not available, use `context/intent-aliases.md` as the manual fallback.

Respect project or organization overrides in `.tailtrail/intent-overrides.json` or `tailtrail/intent-overrides.json` when present.

Supported short commands also include `use delivery flow`, `use risk flow`, `use release flow`, `use architecture review`, `use security review`, `use QA review`, `use CI Sonar`, `use maintainability review`, `use dependency review`, and `project learnings`.

## AIDLC

Use `AIDLC.md` for broad, risky, ambiguous, multi-team, regulated, or long-running work. Resume from `aidlc-docs/aidlc-state.md` when present.

Use only the active stage playbook from `aidlc/stages/`. Use `aidlc/stages/handoff.md` when transferring work to review, validation, operations, or another agent.

## Guardrails

Use only relevant sections from `GUARDRAILS.md` and only the relevant layer from `context/guardrail-layers.md`. Preserve exact code, diffs, configs, commands, dependency versions, IDs, paths, hashes, security rules, policy text, and logs being debugged. For non-trivial work, note files read, commands run, checks performed, assumptions, skipped areas, and residual risk.

## Response Style

Lead with the implementation result or review finding. Keep summaries short: changed, reused, skipped, validated, risk.
