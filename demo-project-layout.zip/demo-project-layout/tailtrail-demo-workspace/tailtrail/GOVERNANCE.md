# TailTrail Governance Source

This file is the single source for the short governance block repeated across project guidance, assistant adapters, and compact guardrail layers.

`GUARDRAILS.md` remains the full behavior contract. This file exists to keep repeated short-form governance text synchronized without turning the whole documentation set into generated output.

Update flow:

```bash
python3 scripts/tailtrail.py governance check
python3 scripts/tailtrail.py governance sync
python3 scripts/tailtrail.py doctor
```

Only the block between the markers below is synchronized. Surrounding tool-specific instructions remain hand-authored.

<!-- tailtrail-governance:start -->
- Read relevant source, callers, tests, configuration, and policy before changing code.
- Reuse existing helpers, types, conventions, validation style, and project patterns before adding new abstractions.
- Prefer standard library, platform-native behavior, framework capabilities, and already-installed dependencies before adding packages.
- Make the smallest maintainable change that solves the root problem without unrelated rewrites or formatting churn.
- Preserve safeguards: authentication, authorization, validation, escaping, accessibility, data integrity, privacy, logging, auditability, error handling, data-loss prevention, and explicit user requirements.
- Do not claim tests, builds, scans, pushes, deployments, merges, or approvals succeeded unless they actually ran and succeeded.
- Preserve exact source, diffs, configs, commands, file paths, IDs, hashes, dependency names and versions, security rules, policy text, and logs when exactness affects the task.
- Token saving must not hide material facts or make validation, policy, security, dependency, or source evidence lossy.
- Use `tailtrail-policy.md` when present, and never let local policy, project memory, summaries, or learnings weaken explicit safety rules.
<!-- tailtrail-governance:end -->

Boundaries:

- Do not generate full `README.md`, `USER-GUIDE.md`, or roadmap content from this file.
- Do not create a hidden policy compiler.
- Keep the synchronized block short enough for assistant instruction files.
